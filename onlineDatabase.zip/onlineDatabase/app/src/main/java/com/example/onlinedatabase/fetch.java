package com.example.onlinedatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class fetch extends AppCompatActivity implements View.OnClickListener
{
    Button delete,update,fetch;
    EditText id,address,name,quali,phnum;

    String id1,name1,address1,quali1,contact1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetch);

        delete=findViewById(R.id.deletefetch);
        delete.setOnClickListener(this);
        update=findViewById(R.id.updatefetch);
        update.setOnClickListener(this);
        fetch=findViewById(R.id.fetchfetch);
        fetch.setOnClickListener(this);
        id=findViewById(R.id.idfetch);
        name=findViewById(R.id.namefetch);
        address=findViewById(R.id.addresssfetch);
        quali=findViewById(R.id.qualifetch);
        phnum=findViewById(R.id.pfnumfetch);

        id1=id.getText().toString();
        name1=name.getText().toString();
        address1=address.getText().toString();
        quali1=quali.getText().toString();
        contact1=phnum.getText().toString();


    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.deletefetch:
            {
                id1=id.getText().toString();
                deletemethod();
                break;
            }
            case R.id.fetchfetch:
            {
                id1=id.getText().toString();
                getData();
                break;
            }
            case R.id.updatefetch:
            {
                id1=id.getText().toString();
                name1=name.getText().toString();
                address1=address.getText().toString();
                quali1=quali.getText().toString();
                contact1=phnum.getText().toString();

                updatemethod();
                break;
            }
        }

    }
    public void getData()
    {
        id1=id.getText().toString();
        if(id1.equals(""))
        {
            Toast.makeText(this, "enter contact id", Toast.LENGTH_SHORT).show();
        }
        RequestQueue rq= Volley.newRequestQueue(fetch.this);
        String url=Config.URL+id1;
        StringRequest sr=new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                showJason(response);
                Toast.makeText(fetch.this, "data fetch", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        rq.add(sr);

    }
    public void showJason(String respose)
    {
        String namej="";
        String addressj="";
        String qualij="";
        String mobilej="";
        try{
            JSONObject jr=new JSONObject(respose);
            JSONArray jt=jr.getJSONArray(Config.KEY_RESULT);
            JSONObject jm=jt.getJSONObject(0);
            namej=jm.getString(Config.KEY_NAME);
            addressj=jm.getString(Config.KEY_ADDRESS);
            qualij=jm.getString(Config.KEY_QUALIFICATION);
            mobilej=jm.getString(Config.KEY_MOBILE);

        }catch(JSONException e)
        {
            e.printStackTrace();
        }
        name.setText(namej);
        address.setText(addressj);
        quali.setText(qualij);
        phnum.setText(mobilej);


    }

    public void updatemethod()
    {
        id1=id.getText().toString();
        name1=name.getText().toString();
        address1=address.getText().toString();
        quali1=quali.getText().toString();
        contact1=phnum.getText().toString();

        RequestQueue rq= Volley.newRequestQueue(fetch.this);//for peer to peer connection
        String url="https://codingvatsalfoundation.000webhostapp.com/studentandroid/update.php";
        StringRequest st=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Toast.makeText(fetch.this, "Successfully updated", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Toast.makeText(fetch.this, error.toString(), Toast.LENGTH_SHORT).show();

            }
        })
        {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String> hm=new HashMap<>();
                hm.put("i",id1);
                hm.put("n",name1);
                hm.put("a",address1);
                hm.put("q",quali1);
                hm.put("m",contact1);

                return hm;
            }
        };
        rq.add(st);
    }

    public void deletemethod()
    {
        id1=id.getText().toString();
        RequestQueue rq= Volley.newRequestQueue(fetch.this);//for peer to peer connection
        String url="https://codingvatsalfoundation.000webhostapp.com/studentandroid/delete.php";
        StringRequest st=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Toast.makeText(fetch.this, "delete successful", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(fetch.this, "delete unsuccessful", Toast.LENGTH_SHORT).show();
            }
        })
        {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String> hm=new HashMap<>();
                hm.put("i",id1);

                return hm;
            }
        };
        rq.add(st);

    }

}
//JSON-java script objecct notation
//REST- representational state transfer
//json reply consists of jason array and json objects
//JSONObject jr=new JSONObject();
//JSONArray ja=jr.getJONArray(();