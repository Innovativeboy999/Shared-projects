package com.example.onlinedatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    Button register,fetch;
    EditText name,id,address,quali,phnum;

    String ids,names,addresss,qualis,phnums;

    //volley is a networking library which is used for transport

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        register=findViewById(R.id.register_button);
        register.setOnClickListener(this);
        name=findViewById(R.id.name);
        id=findViewById(R.id.id);
        address=findViewById(R.id.address_id);
        quali=findViewById(R.id.Qualification_id);
        phnum=findViewById(R.id.phone_number_id);
        fetch=findViewById(R.id.fetch_button);
        fetch.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.fetch_button:
            {
                Intent i=new Intent(this,fetch.class);
                startActivity(i);
                break;
            }

            case R.id.register_button:
            {
                ids=id.getText().toString();
                names=name.getText().toString();
                addresss=address.getText().toString();
                qualis=quali.getText().toString();
                phnums=phnum.getText().toString();

                register();
                break;
            }


        }

    }

    public void register()
    {
        RequestQueue rq= Volley.newRequestQueue(MainActivity.this);//for peer to peer connection
        String url="https://codingvatsalfoundation.000webhostapp.com/studentandroid/register.php";
        StringRequest st=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Toast.makeText(MainActivity.this, "Successfully registered", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();

            }
        })
        {

            @Override
            protected Map<java.lang.String, java.lang.String> getParams() throws AuthFailureError
            {
                HashMap<String,String> hm=new HashMap<>();
                hm.put("i",ids);
                hm.put("n",names);
                hm.put("a",addresss);
                hm.put("q",qualis);
                hm.put("m",phnums);

                return hm;
            }
        };
        rq.add(st);
    }
}
