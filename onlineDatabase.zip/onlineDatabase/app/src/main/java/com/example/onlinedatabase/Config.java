package com.example.onlinedatabase;

import java.net.URL;

public class Config
{
    //these strigs are set in accordance with what we get after executing fetch.php
    public static final String URL="https://codingvatsalfoundation.000webhostapp.com/studentandroid/fetch.php?i=";
    public static final String KEY_NAME="NAME";
    public static final String KEY_ADDRESS="ADDRESS";
    public static final String KEY_QUALIFICATION="QUALIFICATION";
    public static final String KEY_MOBILE="MOBILE";
    public static final String KEY_RESULT="result";
}
